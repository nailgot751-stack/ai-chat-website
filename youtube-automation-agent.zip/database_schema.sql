# YouTube Automation Agent - Database Schema
# File: schema.sql
# PostgreSQL DDL for production deployment

-- ============================================================================
-- EXTENSIONS
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================================
-- ENUM TYPES
-- ============================================================================

CREATE TYPE task_status AS ENUM (
    'pending',
    'in_progress',
    'completed',
    'failed'
);

CREATE TYPE task_type AS ENUM (
    'research',
    'script_generation',
    'tts_generation',
    'thumbnail_generation',
    'seo_optimization',
    'video_upload'
);

CREATE TYPE video_status AS ENUM (
    'draft',
    'published',
    'scheduled'
);

-- ============================================================================
-- USERS & AUTHENTICATION
-- ============================================================================

CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(255),
    subscription_tier VARCHAR(50) DEFAULT 'free',
    api_key_hash VARCHAR(255),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_api_key ON users(api_key_hash);

-- ============================================================================
-- PROJECTS
-- ============================================================================

CREATE TABLE projects (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    niche VARCHAR(100),
    target_audience JSONB,
    channel_id VARCHAR(255) UNIQUE,
    youtube_auth_token VARCHAR(500),
    status VARCHAR(50) DEFAULT 'active',
    monthly_budget DECIMAL(10, 2) DEFAULT 50.00,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_projects_user_id ON projects(user_id);
CREATE INDEX idx_projects_channel_id ON projects(channel_id);
CREATE INDEX idx_projects_niche ON projects(niche);

-- ============================================================================
-- EXECUTION PLANS
-- ============================================================================

CREATE TABLE execution_plans (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    goal VARCHAR(500) NOT NULL,
    objective_type VARCHAR(50),
    estimated_cost DECIMAL(10, 2),
    estimated_duration_minutes INTEGER,
    tool_mapping JSONB,
    plan_data JSONB,
    status VARCHAR(50) DEFAULT 'created',
    created_at TIMESTAMP DEFAULT NOW(),
    started_at TIMESTAMP,
    completed_at TIMESTAMP
);

CREATE INDEX idx_plans_project_id ON execution_plans(project_id);
CREATE INDEX idx_plans_status ON execution_plans(status);

-- ============================================================================
-- TASKS (Core workflow management)
-- ============================================================================

CREATE TABLE tasks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    plan_id UUID REFERENCES execution_plans(id) ON DELETE SET NULL,
    task_type task_type NOT NULL,
    status task_status DEFAULT 'pending',
    priority INTEGER DEFAULT 0,
    input_data JSONB,
    output_data JSONB,
    tool_used VARCHAR(100),
    cost_usd DECIMAL(10, 4) DEFAULT 0,
    execution_time_seconds INTEGER,
    is_parallel BOOLEAN DEFAULT FALSE,
    dependencies JSONB DEFAULT '[]'::jsonb,
    retry_count INTEGER DEFAULT 0,
    max_retries INTEGER DEFAULT 3,
    error_message TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_tasks_project_id ON tasks(project_id);
CREATE INDEX idx_tasks_status ON tasks(status);
CREATE INDEX idx_tasks_task_type ON tasks(task_type);
CREATE INDEX idx_tasks_plan_id ON tasks(plan_id);
CREATE INDEX idx_tasks_created_at ON tasks(created_at DESC);

-- ============================================================================
-- VIDEOS
-- ============================================================================

CREATE TABLE videos (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    plan_id UUID REFERENCES execution_plans(id),
    title VARCHAR(255) NOT NULL,
    description TEXT,
    script TEXT,
    video_id VARCHAR(255) UNIQUE,
    thumbnail_url VARCHAR(500),
    video_url VARCHAR(500),
    status video_status DEFAULT 'draft',
    seo_metadata JSONB,
    publication_date TIMESTAMP,
    scheduled_publish_time TIMESTAMP,
    view_count INTEGER DEFAULT 0,
    like_count INTEGER DEFAULT 0,
    comment_count INTEGER DEFAULT 0,
    share_count INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT NOW(),
    published_at TIMESTAMP,
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_videos_project_id ON videos(project_id);
CREATE INDEX idx_videos_video_id ON videos(video_id);
CREATE INDEX idx_videos_status ON videos(status);
CREATE INDEX idx_videos_published_at ON videos(published_at DESC);

-- ============================================================================
-- PERFORMANCE METRICS (Analytics)
-- ============================================================================

CREATE TABLE performance_metrics (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    video_id UUID NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    views INTEGER DEFAULT 0,
    watch_time_minutes DECIMAL(10, 2) DEFAULT 0,
    avg_view_duration DECIMAL(10, 2) DEFAULT 0,
    watch_time_percentage DECIMAL(5, 2) DEFAULT 0,
    ctr DECIMAL(5, 2) DEFAULT 0,
    engagement_rate DECIMAL(5, 2) DEFAULT 0,
    likes INTEGER DEFAULT 0,
    comments INTEGER DEFAULT 0,
    shares INTEGER DEFAULT 0,
    subscriber_gain INTEGER DEFAULT 0,
    unsubscribe_count INTEGER DEFAULT 0,
    traffic_source JSONB,
    device_type JSONB,
    audience_demographics JSONB,
    recorded_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(video_id, date)
);

CREATE INDEX idx_metrics_video_id ON performance_metrics(video_id);
CREATE INDEX idx_metrics_date ON performance_metrics(date DESC);

-- ============================================================================
-- TOOL CONFIGURATIONS (API Keys & Settings)
-- ============================================================================

CREATE TABLE tool_configurations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    tool_name VARCHAR(100) NOT NULL,
    api_key BYTEA,
    config_params JSONB,
    is_active BOOLEAN DEFAULT TRUE,
    rate_limit_per_minute INTEGER,
    rate_limit_per_day INTEGER,
    cost_per_call DECIMAL(10, 4),
    usage_count INTEGER DEFAULT 0,
    last_used_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(project_id, tool_name)
);

CREATE INDEX idx_tool_config_project ON tool_configurations(project_id);
CREATE INDEX idx_tool_config_active ON tool_configurations(is_active);

-- ============================================================================
-- API USAGE & BILLING
-- ============================================================================

CREATE TABLE api_usage (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    tool_name VARCHAR(100),
    task_id UUID REFERENCES tasks(id),
    cost_usd DECIMAL(10, 4),
    timestamp TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_usage_user_id ON api_usage(user_id);
CREATE INDEX idx_usage_project_id ON api_usage(project_id);
CREATE INDEX idx_usage_timestamp ON api_usage(timestamp DESC);

-- ============================================================================
-- FEEDBACK & OPTIMIZATION RULES
-- ============================================================================

CREATE TABLE optimization_rules (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
    rule_type VARCHAR(100),
    metric_name VARCHAR(100),
    threshold_value DECIMAL(10, 2),
    condition VARCHAR(50), -- 'below', 'above', 'equals'
    action_type VARCHAR(100),
    action_params JSONB,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_rules_project_id ON optimization_rules(project_id);
CREATE INDEX idx_rules_active ON optimization_rules(is_active);

-- ============================================================================
-- CONTENT VARIATIONS (A/B Testing)
-- ============================================================================

CREATE TABLE content_variations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    video_id UUID NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
    variation_type VARCHAR(50), -- 'hook', 'thumbnail', 'title'
    variation_a VARCHAR(500),
    variation_b VARCHAR(500),
    variation_c VARCHAR(500),
    winning_variation VARCHAR(10),
    sample_size INTEGER,
    performance_data JSONB,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_variations_video_id ON content_variations(video_id);

-- ============================================================================
-- AUDIT LOG (Compliance & Monitoring)
-- ============================================================================

CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    action_type VARCHAR(100),
    resource_type VARCHAR(100),
    resource_id VARCHAR(255),
    changes JSONB,
    ip_address INET,
    user_agent TEXT,
    timestamp TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_audit_user_id ON audit_logs(user_id);
CREATE INDEX idx_audit_timestamp ON audit_logs(timestamp DESC);

-- ============================================================================
-- TEMPLATES (for content generation)
-- ============================================================================

CREATE TABLE script_templates (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255),
    niche VARCHAR(100),
    structure JSONB,
    hook_examples TEXT[],
    tone VARCHAR(50),
    average_duration_seconds INTEGER,
    performance_rating DECIMAL(3, 2),
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_templates_niche ON script_templates(niche);

-- ============================================================================
-- SESSION MANAGEMENT
-- ============================================================================

CREATE TABLE sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash VARCHAR(255),
    expires_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW(),
    last_activity TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_sessions_user_id ON sessions(user_id);
CREATE INDEX idx_sessions_expires_at ON sessions(expires_at);

-- ============================================================================
-- MATERIALIZED VIEWS FOR ANALYTICS
-- ============================================================================

CREATE MATERIALIZED VIEW project_performance_summary AS
SELECT
    p.id AS project_id,
    p.name,
    COUNT(DISTINCT v.id) AS total_videos,
    SUM(v.view_count) AS total_views,
    AVG(pm.ctr) AS avg_ctr,
    AVG(pm.watch_time_percentage) AS avg_watch_percentage,
    AVG(pm.engagement_rate) AS avg_engagement,
    MAX(pm.date) AS last_updated
FROM projects p
LEFT JOIN videos v ON p.id = v.project_id
LEFT JOIN performance_metrics pm ON v.id = pm.video_id
GROUP BY p.id, p.name;

CREATE INDEX idx_project_perf_project_id ON project_performance_summary(project_id);

-- ============================================================================
-- FUNCTIONS
-- ============================================================================

-- Function to calculate video performance score
CREATE OR REPLACE FUNCTION calculate_video_score(video_id UUID)
RETURNS DECIMAL AS $$
DECLARE
    ctr_score DECIMAL;
    watch_time_score DECIMAL;
    engagement_score DECIMAL;
    total_score DECIMAL;
BEGIN
    SELECT
        COALESCE(AVG(ctr), 0) * 10 as ctr_score,
        COALESCE(AVG(watch_time_percentage), 0) / 10 as watch_time_score,
        COALESCE(AVG(engagement_rate), 0) * 5 as engagement_score
    INTO ctr_score, watch_time_score, engagement_score
    FROM performance_metrics
    WHERE video_id = video_id;
    
    total_score := ctr_score + watch_time_score + engagement_score;
    
    RETURN ROUND(total_score, 2);
END;
$$ LANGUAGE plpgsql;

-- Function to update project last activity
CREATE OR REPLACE FUNCTION update_project_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- TRIGGERS
-- ============================================================================

CREATE TRIGGER update_project_modified
BEFORE UPDATE ON projects
FOR EACH ROW
EXECUTE FUNCTION update_project_timestamp();

CREATE TRIGGER update_video_modified
BEFORE UPDATE ON videos
FOR EACH ROW
EXECUTE FUNCTION update_project_timestamp();

-- ============================================================================
-- INITIAL DATA (Optional)
-- ============================================================================

INSERT INTO script_templates (name, niche, structure, tone, average_duration_seconds)
VALUES
(
    'Educational Series',
    'tech',
    '{"hook": "15s", "intro": "30s", "main_content": "240s", "examples": "60s", "cta": "15s"}'::jsonb,
    'professional',
    360
),
(
    'Motivational Story',
    'motivation',
    '{"hook": "10s", "problem": "60s", "journey": "240s", "solution": "45s", "cta": "15s"}'::jsonb,
    'inspiring',
    370
);

-- ============================================================================
-- GRANTS (if using separate app user)
-- ============================================================================

-- GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO app_user;
-- GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO app_user;
